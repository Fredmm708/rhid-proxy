// ══════════════════════════════════════════════════════════
//  RHiD Proxy — Vercel Serverless Function
//  Resolve CORS entre o dashboard e a API do RHiD na nuvem
// ══════════════════════════════════════════════════════════

const RHID_BASE = 'https://www.rhid.com.br/v2';

export default async function handler(req, res) {

  // --- CORS: permite chamadas do dashboard de qualquer origem ---
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // --- Roteamento por ?action= ---
  const { action } = req.query;

  try {
    switch (action) {

      // ── LOGIN ─────────────────────────────────────────────
      // POST /api/rhid?action=login
      // Body: { login, password }
      case 'login': {
        const { login, password } = req.body;

        if (!login || !password) {
          return res.status(400).json({ error: 'Campos login e password são obrigatórios.' });
        }

        const response = await fetch(`${RHID_BASE}/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ login, password }),
        });

        const data = await response.json();

        if (!response.ok) {
          return res.status(response.status).json({
            error: 'Falha no login do RHiD.',
            detail: data,
          });
        }

        // Retorna token JWT para o dashboard armazenar
        return res.status(200).json({
          token: data.token || data.access_token || data,
          raw: data,
        });
      }

      // ── RESUMO POR EMPRESA (equivalente ao relatório CSV) ──
      // GET /api/rhid?action=resumo&token=JWT&inicio=2026-01-01&fim=2026-05-31
      case 'resumo': {
        const { token, inicio, fim } = req.query;

        if (!token) return res.status(401).json({ error: 'Token JWT ausente.' });

        const url = `${RHID_BASE}/relatorios/resumo-empresa?inicio=${inicio || ''}&fim=${fim || ''}`;

        const response = await fetch(url, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
        });

        const data = await response.json();
        return res.status(response.ok ? 200 : response.status).json(data);
      }

      // ── FUNCIONÁRIOS ───────────────────────────────────────
      // GET /api/rhid?action=funcionarios&token=JWT&empresa=123
      case 'funcionarios': {
        const { token, empresa } = req.query;

        if (!token) return res.status(401).json({ error: 'Token JWT ausente.' });

        const url = `${RHID_BASE}/funcionarios${empresa ? `?empresa=${empresa}` : ''}`;

        const response = await fetch(url, {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${token}` },
        });

        const data = await response.json();
        return res.status(response.ok ? 200 : response.status).json(data);
      }

      // ── MARCAÇÕES / REGISTROS DE PONTO ────────────────────
      // GET /api/rhid?action=marcacoes&token=JWT&inicio=2026-01-01&fim=2026-05-31&empresa=123
      case 'marcacoes': {
        const { token, inicio, fim, empresa } = req.query;

        if (!token) return res.status(401).json({ error: 'Token JWT ausente.' });

        const params = new URLSearchParams();
        if (inicio)  params.set('inicio', inicio);
        if (fim)     params.set('fim', fim);
        if (empresa) params.set('empresa', empresa);

        const url = `${RHID_BASE}/marcacoes?${params.toString()}`;

        const response = await fetch(url, {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${token}` },
        });

        const data = await response.json();
        return res.status(response.ok ? 200 : response.status).json(data);
      }

      // ── EMPRESAS ───────────────────────────────────────────
      // GET /api/rhid?action=empresas&token=JWT
      case 'empresas': {
        const { token } = req.query;

        if (!token) return res.status(401).json({ error: 'Token JWT ausente.' });

        const response = await fetch(`${RHID_BASE}/empresas`, {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${token}` },
        });

        const data = await response.json();
        return res.status(response.ok ? 200 : response.status).json(data);
      }

      // ── PROXY GENÉRICO (para endpoints ainda não mapeados) ──
      // POST /api/rhid?action=proxy
      // Body: { token, method, endpoint, body }
      case 'proxy': {
        const { token, method = 'GET', endpoint, body: proxyBody } = req.body;

        if (!token)    return res.status(401).json({ error: 'Token JWT ausente.' });
        if (!endpoint) return res.status(400).json({ error: 'Endpoint ausente.' });

        const response = await fetch(`${RHID_BASE}${endpoint}`, {
          method,
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: method !== 'GET' && proxyBody ? JSON.stringify(proxyBody) : undefined,
        });

        const data = await response.json();
        return res.status(response.ok ? 200 : response.status).json(data);
      }

      default:
        return res.status(400).json({
          error: 'Ação inválida.',
          acoes_disponiveis: ['login', 'resumo', 'funcionarios', 'marcacoes', 'empresas', 'proxy'],
        });
    }

  } catch (err) {
    console.error('[RHiD Proxy Error]', err);
    return res.status(500).json({
      error: 'Erro interno no proxy.',
      detail: err.message,
    });
  }
}
